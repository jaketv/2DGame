package eecs40.a2dgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

/**
 * Created by Jake on 5/17/2016.
 */

//A floor that the player will be able to stand on.
public class Floor extends GameObject{
    private Bitmap image;
    public Floor(Bitmap res, int x, int y){
        width = 80;
        height = 50;

        this.x = x;
        this.y = y;

        dx = GameWorld.gameSpeed;
        image = Bitmap.createBitmap(res, 0, 0, width, height);

    }
    public void update(){
        x+=dx;
    }
    public void draw(Canvas c){
        try{c.drawBitmap(image,x,y,null);}catch(Exception e){};
    }
}
