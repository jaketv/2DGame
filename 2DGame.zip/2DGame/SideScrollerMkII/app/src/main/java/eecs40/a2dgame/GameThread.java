package eecs40.a2dgame;

import android.graphics.Canvas;
import android.provider.Settings;
import android.view.SurfaceHolder;

/**
 * Created by Jake on 5/17/2016.
 */
public class GameThread extends Thread {
    private int Frames = 50;
    private SurfaceHolder surfaceHolder;
    private GameWorld gameWorld;
    private boolean isRunning;
    public static Canvas c;

    public GameThread(SurfaceHolder surfaceHolder, GameWorld gameWorld){
        super();
        this.surfaceHolder = surfaceHolder;
        this.gameWorld = gameWorld;

    }
    @Override
    public void run(){

        while(isRunning){
            c = null;

            try{
                c = this.surfaceHolder.lockCanvas();
                synchronized (surfaceHolder){
                    this.gameWorld.update();
                    this.gameWorld.draw(c);
                }
            }catch(Exception e){}
            finally {
                if(c!=null){
                    try{surfaceHolder.unlockCanvasAndPost(c);
                }catch (Exception e){e.printStackTrace();}
            }



            try{
                this.sleep(1000/Frames);
            }catch(Exception e){}
        }
    }}
    public void setRunning(boolean b){
        isRunning = b;
    }
}
