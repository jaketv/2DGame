package eecs40.a2dgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import java.util.Random;

//An object that will grant +1 HP to the player upon collision.
    public class Health extends GameObject{
        private int score;
        private int speed;
        private Random r = new Random();
        private Animation animation = new Animation();
        private Bitmap spritesheet;
        public Health(Bitmap res, int x, int y, int w, int h, int s, int frameNum){
            this.x = x;
            this.y = y;
            score = s;
            width = w;
            height = h;
            hp=1;

            //enemies will have random speed and get faster based on score, but capped at 30
            speed = 5;
            Bitmap[] image = new Bitmap[frameNum];
            spritesheet =res;
            for(int i =0; i<image.length;i++){
                image[i] = Bitmap.createBitmap(spritesheet, 0 , i*height, width, height);
            }
            animation.setFrames(image);
            animation.setDelay(100-speed);
        }

        public void update(){
            x-=speed;
            animation.update();
        }
        public void draw(Canvas c){
            try{
                c.drawBitmap(animation.getImage(),x,y,null);
            }catch(Exception e){}
        }

    }

