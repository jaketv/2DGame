package eecs40.a2dgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import java.util.Random;

/**
 * Created by Jake on 5/17/2016.
 */

//An enemy that flies towards and attempts to crash into the player
    public class Dasher extends GameObject{
    private int score;
    private int speed;
    private Random r = new Random();
    private Animation animation = new Animation();
    private Bitmap spritesheet;
    public Dasher(Bitmap res, int x, int y, int w, int h, int s, int frameNum){
        this.x = x;
        this.y = y;
        score = s;
        width = w;
        height = h;
        hp=1;

        //Dashers will have random speed and get faster based on score, but capped at 30
        speed = 5 + (r.nextInt()*score/30);
        if(speed >30){
            speed =30;
        }
        Bitmap[] image = new Bitmap[frameNum];
        spritesheet =res;
        for(int i =0; i<image.length;i++){
            image[i] = Bitmap.createBitmap(spritesheet, 0 , i*height, width, height);
        }
        animation.setFrames(image);
        animation.setDelay(100-speed);
    }

    public void update(){
        x-=speed;
        animation.update();
    }
    public void draw(Canvas c){
        try{
            c.drawBitmap(animation.getImage(),x,y,null);
        }catch(Exception e){}
    }

}
