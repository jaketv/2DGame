package eecs40.a2dgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import java.util.Random;

/**
 * Created by Jake on 5/18/2016.
 */

//Bullets can be fired from either player or enemy(Boomer).
public class Bullet extends GameObject{
    private int speed;
    private int facing;
    private Animation animation = new Animation();
    private Bitmap spritesheet;
    public Bullet(Bitmap res, int x, int y, int w, int h, int frameNum, int facing){
        this.x = x;
        this.y = y;
        this.facing = facing;
        width = w;
        height = h;
        hp=1;


        speed = 20;
        Bitmap[] image = new Bitmap[frameNum];
        spritesheet =res;
        for(int i =0; i<image.length;i++){
            image[i] = Bitmap.createBitmap(spritesheet, 0 , i*height, width, height);
        }
        animation.setFrames(image);
        animation.setDelay(100-speed);
    }

    public void update(){
        x+=speed*facing;
        animation.update();
    }
    public void draw(Canvas c){
        try{
            c.drawBitmap(animation.getImage(),x,y,null);
        }catch(Exception e){}
    }

}
