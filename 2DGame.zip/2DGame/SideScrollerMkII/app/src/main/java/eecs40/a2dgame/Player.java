package eecs40.a2dgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;


/**
 * Created by Jake on 5/17/2016.
 */
public class Player extends GameObject{
    private Bitmap spritesheet;
    private int score;
    private boolean jump;
    private boolean isPlaying;
    private Animation animation = new Animation();
    private long startTime;

    public Player(Bitmap res, int w, int h, int Frames){
        score = 0;
        hp = 5;
        x = 100;
        y = GameWorld.Height/2;
        dy = 0;
        height = h;
        width = w;

        //creates a bitmap array for the number of frames we have in the image
        //In this case, there are two
        Bitmap[] image = new Bitmap[Frames];
        spritesheet = res;
        for (int i = 0; i<image.length; i++){
            image[i] = Bitmap.createBitmap(spritesheet,i*width,0,width,height);

        }
        animation.setFrames(image);
        animation.setDelay(10);
        startTime = System.nanoTime();
    }

    public void setJump(boolean b){
        jump = b;
    }

    public void update(){
        long elapsed = (System.nanoTime()-startTime)/1000000;
        if(elapsed>100){
            score++;
            //System.out.println(score);
            startTime = System.nanoTime();
        }
        animation.update();

        //Player will fall if not jumping (Gravity)
        if(jump){
            dy -=1;
        }
        else{
            dy +=1;
        }

        if(dy>10){
            dy = 10;
        }
        if(dy<-10){
            dy = -10;
        }

        //below top of screen is allowed to 'jump'
        if(y>21) {
            y += dy * 2;
        }
        //keeps player from leaving top of screen
        else if(y<=21){
            y = 22;
            dy = 0;
        }
    }

    public void draw(Canvas c){
        c.drawBitmap(animation.getImage(),x,y,null);
    }

    public void setScore(int score){
        this.score = score;
    }

    public int getScore(){
        return score;
    }

    public boolean getPlaying(){
        return isPlaying;
    }

    public void setPlaying(boolean b){
        isPlaying = b;
    }

    public void resetDY(){
        dy = 0;
    }
    public void resetScore(){
        score = 0;
    }
}
