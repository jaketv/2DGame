package eecs40.a2dgame;

import android.graphics.Bitmap;

/**
 * Created by Jake on 5/17/2016.
 */

//Animates sprites
public class Animation {
    private Bitmap[] Frames;
    private int currentFrame;
    private long startTime;
    private long delay;
    private boolean playedOnce;

    public void setFrames(Bitmap[] frames){
       this.Frames = frames;
        currentFrame = 0;
        startTime = System.nanoTime();
    }

    public void setDelay(long d){
        delay = d;
    }

    public Bitmap getImage(){
        return Frames[currentFrame];
    }

    public void update(){
        long elapsed = (System.nanoTime()-startTime)/1000000;

        if (elapsed>delay){
            currentFrame++;
            startTime = System.nanoTime();
        }
        if (currentFrame == Frames.length){
            currentFrame = 0;
            playedOnce = true;
        }
    }

}
