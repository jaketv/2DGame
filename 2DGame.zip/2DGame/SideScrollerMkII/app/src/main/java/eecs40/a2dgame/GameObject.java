package eecs40.a2dgame;

import android.graphics.Rect;

/**
 * Created by Jake on 5/17/2016.
 */

//An abstract class defining methods that can be used by all classes that extend GameObject.
public abstract class GameObject {
    protected int x, y, dx, dy, width, height, hp;

    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public int getWidth(){
        return width;
    }
    public int getHeight(){
        return height;
    }
    public void setHP(int hp){
        this.hp = hp;
    }
    public int getHP(){return hp;}
    public Rect getRect(){
        return new Rect(x,y,x+width,y+height);
    }
}
