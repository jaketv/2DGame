package eecs40.a2dgame;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import java.util.Random;

/**
 * Created by Jake on 5/18/2016.
 */

//A type of enemy that flies up and down, and fires whenever it sees the player
public class Boomer extends GameObject{
    private int score;
    private int speed;
    private Random r = new Random();
    private Animation animation = new Animation();
    private Bitmap spritesheet;
    private int vy = 5;

    public Boomer(Bitmap res, int x, int y, int w, int h, int s, int frameNum){
        this.x = x;
        this.y = y;
        score = s;
        width = w;
        height = h;
        hp=1;
        vy = 7;


        Bitmap[] image = new Bitmap[frameNum];
        spritesheet =res;
        for(int i =0; i<image.length;i++){
            image[i] = Bitmap.createBitmap(spritesheet, 0 , i*height, width, height);
        }
        animation.setFrames(image);
        animation.setDelay(100-speed);
    }

    public void update(){
        if (y>GameWorld.Height-200 && vy>0)
            vy=-vy;
            y=y+vy;
        if (y<0 && vy<0)
            vy=-vy;
            y=y+vy;
        animation.update();
    }
    public void draw(Canvas c){
        try{
            c.drawBitmap(animation.getImage(),x,y,null);
        }catch(Exception e){}
    }

}
