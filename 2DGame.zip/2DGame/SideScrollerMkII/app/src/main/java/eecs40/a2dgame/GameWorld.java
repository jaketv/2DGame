package eecs40.a2dgame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Jake on 5/17/2016.
 */

public class GameWorld extends SurfaceView implements SurfaceHolder.Callback{
    //size of background
    public static final int Width = 900;
    public static final int Height = 450;
    public static final int gameSpeed = - 4;
    private long dasherStartTime;
    private GameThread thread;
    private Background background;
    private Player player;
    private ArrayList<Dasher> dashers;
    private ArrayList<Floor> floor;
    private ArrayList<Bullet> bullets;
    private ArrayList<Bullet> enemyShots;
    private ArrayList<Health> items;
    private ArrayList<Boomer> boomers;
    private ArrayList<Flag> flag;
    private Random r = new Random();
    //Default Game Logic -- Do not change
    private boolean ReadyGame = false;
    private boolean fire = false;
    private boolean isBoomer = false;
    private boolean isItem = false;
    private boolean isBullet = false;
    private boolean isFlag = false;
    private int level = 1;
    private int score = 0;
    private int HP;


    public GameWorld(Context context){
        super(context);
        getHolder().addCallback(this);
        thread = new GameThread(getHolder(), this);
        setFocusable(true);
    }
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean restart = true;
        int counter = 0;
        while (restart && counter<1000) {
            try {
                thread.setRunning(false);
                thread.join();
                restart = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        }

    @Override
    public void surfaceCreated(SurfaceHolder holder){
        background = new Background(BitmapFactory.decodeResource(getResources(),R.drawable.city));
        player = new Player(BitmapFactory.decodeResource(getResources(),R.drawable.rushjet),50,43,2);
        dashers = new ArrayList<Dasher>();
        items = new ArrayList<Health>();
        floor = new ArrayList<Floor>();
        bullets = new ArrayList<Bullet>();
        enemyShots = new ArrayList<Bullet>();
        boomers = new ArrayList<Boomer>();
        flag = new ArrayList<Flag>();
        dasherStartTime = System.nanoTime();
        //game loop
        thread.setRunning(true);
        thread.start();
        }

    //Creates a new Game and resets game logic. Can also be used to start new level.
    public void newGame()
    {
        level = 1;
        flag.clear();
        enemyShots.clear();
        bullets.clear();
        boomers.clear();
        floor.clear();
        items.clear();
        dashers.clear();
        player.resetScore();
        player.setY(Height/2);
        player.setHP(5);

        for(int i =0; i*80<Width+80;i++){

                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),i*80,430));

        }
        isFlag = false;
        ReadyGame = true;
        isItem = false;
        isBoomer = false;
        isBullet = false;
    }

    //Checks if two objects collide with each other.
    public boolean collision(GameObject a, GameObject b){
        if(Rect.intersects(a.getRect(),b.getRect())){
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e){

        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            float posx, posy;
            posx = e.getX();
            posy = e.getY();

            //jump if left side of screen is pushed
            if (posx <= ((this.getWidth() / 2) - 1)) {
                if (!player.getPlaying()) {
                    player.setPlaying(true);
                } else {
                    player.setJump(true);
                }
                return true;
            }
            //fire if right side of screen is pressed
           if (posx >= ((this.getWidth() / 2))) {
                fire = true;
                return true;
            }
        }



        if(e.getAction() == MotionEvent.ACTION_UP){
            player.setJump(false);
            return true;
        }
        return super.onTouchEvent(e);
    }

    public void updateFloor(){
        if(player.getScore()%15 == 0){
            //Here add the variations of level you want by changing the height in an if statement
            //Add new 'else if' statement for level variation
            if(player.getScore() > 100 && player.getScore() < 150){
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,200));
            }
            else if(player.getScore() > 350 && player.getScore() < 500){
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,100));
            }
            else if(player.getScore() > 800 && player.getScore() < 1000){
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,330));
            }
            else if(player.getScore() >= 1000 && player.getScore() < 1200){
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,Height+100));
            }
            else if(player.getScore() > 1300 && player.getScore() < 1500){
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,130));
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-2).getX()+80,330));
            }
            else if(player.getScore() > 2000 && player.getScore() < 2200){
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,230));
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,330));
            }
            //This is the default case
            else {
                floor.add(new Floor(BitmapFactory.decodeResource(getResources(),R.drawable.block),floor.get(floor.size()-1).getX()+80,430));
            }
        }
        //Player collision with floor tiles
        for(int i = 0; i < floor.size(); i++){
            floor.get(i).update();
            if(collision(floor.get(i), player)){
                //for when player is above floor
                if((player.y - 10 < floor.get(i).y)){
                player.y = floor.get(i).y - 42;
                player.resetDY();}
                //for when player is below floor
                else if(player.y -10 > floor.get(i).y){
                    player.y = floor.get(i).y + 50;
                    player.resetDY();
                    }
                }


            //delete past floor tiles
            if(floor.get(i).getX()<-80){
                floor.remove(i);
            }
        }
    }

    public void drawText(Canvas c){
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(20);
        c.drawText("HP: "+(player.getHP()), 100, 20, paint);
        c.drawText("Level: "+level, 400, 20, paint );
        c.drawText("Score: "+(player.getScore()), 700, 20, paint);
        c.drawText("Press to go up!", 10, 40, paint);
        c.drawText("Tap to shoot!", Width - 200, 40, paint);

    }

    public void update(){
        if(!ReadyGame){
            newGame();
        }
        if(player.getPlaying()){
            player.update();
            //Kill player if he falls offscreen.
            if(player.y > Height + 30){
                player.setHP(0);
                if(player.getHP() == 0){
                    player.setPlaying(false);
                    player.resetDY();
                    ReadyGame = false;
                }
            }
            background.update();

            //update floor
            this.updateFloor();

            //Fire bullets
            if(fire){
                bullets.add(new Bullet(BitmapFactory.decodeResource(getResources(),R.drawable.lemon),player.x+10,player.y,17,16,1,1));
                fire = false;
            }
            for(int i = 0; i< bullets.size(); i++) {
                bullets.get(i).update();
                //remove bullet if it's too far offscreen
                if (bullets.get(i).getX() > Width + 100) {
                    bullets.remove(i);
                    break;
                }
                //destroys enemies, causes some lag..
                for (int j = 0; j < dashers.size(); j++) {
                    if (collision(bullets.get(i), dashers.get(j))) {
                        bullets.remove(i);
                        dashers.remove(j);
                    }
                }
                for(int k = 0; k< boomers.size(); k++){
                    if (collision(bullets.get(i), boomers.get(k))) {
                        bullets.remove(i);
                        boomers.remove(k);
                        isBoomer = false;
                    }
                }
            }

            //Spawn new level flag pole
            if (player.getScore()==600*level && !isFlag){
                flag.add(new Flag(BitmapFactory.decodeResource(getResources(),R.drawable.flag),Width -100,10,149,479,player.getScore(),1));
                isFlag = true;
            }
            for(int i = 0; i<flag.size();i++){
                flag.get(i).update();
                //Creates a new level while keeping same score and HP upon collision.
                if (collision(flag.get(i),player)){
                    System.out.println("Spawned Boomer");
                    int tempScore = player.getScore();
                    int tempLevel = level+1;
                    int tempHP = player.getHP();
                    newGame();
                    player.setScore(tempScore);
                    level = tempLevel;
                    player.setHP(tempHP);
                }
            }

            //spawn Health item
            if (player.getScore()%250 == 0 && !isItem){
                items.add(new Health(BitmapFactory.decodeResource(getResources(),R.drawable.health),Width +10,Height/2,32,32,player.getScore(),1));
                isItem = true;
            }
            for(int j = 0; j<items.size();j++) {
                items.get(j).update();
                //Add HP to player if there is collision
                if (collision(items.get(j), player)) {
                    items.remove(j);
                    isItem = false;
                    if (player.getHP() > 0 && player.getHP() < 5) {
                        player.setHP(player.getHP() + 1);
                        break;
                    }
                }
                //remove item if it's too far offscreen
                if (items.get(j).getX() < -100) {
                    items.remove(j);
                    isItem = false;
                    break;
                }
            }

            //spawns 'Boomer' enemy
            if ((player.getScore()%(400/level) == 0) && !isBoomer){
                boomers.add(new Boomer(BitmapFactory.decodeResource(getResources(),R.drawable.boomer),Width-100,Height/2,100,83,player.getScore(),1));
                System.out.println("Spawned Boomer");
                isBoomer = true;
            }
            for(int i = 0; i<boomers.size();i++){
                boomers.get(i).update();
                //shoots if at same y pos as player
                if(((player.y < boomers.get(i).y + 41) && (player.y > boomers.get(i).y - 41))&& !isBullet){
                    enemyShots.add(new Bullet(BitmapFactory.decodeResource(getResources(),R.drawable.lemon),Width-200,player.y,17,16,1,-1));
                    isBullet = true;
                    System.out.println("Shot at!");
                }
            }

            //enemy bullet collision
            for(int i = 0; i<enemyShots.size();i++){
                enemyShots.get(i).update();
                if(collision(enemyShots.get(i),player)){
                    enemyShots.remove(i);
                    isBullet = false;
                    if (player.getHP()>0){
                        player.setHP(player.getHP()-1);
                        if(player.getHP() == 0){
                            player.setPlaying(false);
                            ReadyGame = false;
                            break;
                        }
                    }
                }
                //remove enemy shot if it's too far offscreen
                if(enemyShots.get(i).getX()<-100){
                    enemyShots.remove(i);
                    isBullet = false;
                    break;
                }

            }


            //spawn enemies on timer, more enemies spawn the higher the score
            long dasherElapsedTime = (System.nanoTime() - dasherStartTime)/1000000;
            if (dasherElapsedTime> (2000 - player.getScore()/4)){

                dashers.add(new Dasher(BitmapFactory.decodeResource(getResources(),R.drawable.fishy),Width +10,2*Height/3 - r.nextInt(6)*50,100,70,player.getScore(),1));
                System.out.println("Spawned Dasher");
                dasherStartTime = System.nanoTime();
            }

            //check for player collision with every dasher
            //if player's HP drops to 0, stop the game
            for(int i = 0; i<dashers.size();i++){
                dashers.get(i).update();
                if(collision(dashers.get(i),player)){
                    dashers.remove(i);
                    if (player.getHP()>0){
                    player.setHP(player.getHP()-1);
                    if(player.getHP() == 0){
                        player.setPlaying(false);
                        ReadyGame = false;
                        break;
                    }
                    }
                }
                //remove dasher if it's too far offscreen
                if(dashers.get(i).getX()<-100){
                    dashers.remove(i);
                    break;
                }

            }
        }

    }
    @Override
    public void draw(Canvas c){
        //Scale the city.png image to be the size of the screen
        final float scaleX = getWidth()/(Width*1.f);
        final float scaley = getHeight()/(Height*1.f);
        if(c!=null){
            final int savedImage = c.save();
            c.scale(scaleX,scaley);
            background.draw(c);
            player.draw(c);
            drawText(c);
            for(Dasher d: dashers){
                d.draw(c);
            }
            for(Health h: items){
                h.draw(c);
            }
            for(Bullet b: bullets){
                b.draw(c);
            }
            for(Boomer bo: boomers){
                bo.draw(c);
            }
            for(Bullet bull: enemyShots){
                bull.draw(c);
            }
            for(Flag fl: flag){
                fl.draw(c);
            }
            for(Floor f: floor){
                f.draw(c);
            }
            c.restoreToCount(savedImage);
        }
    }
}
