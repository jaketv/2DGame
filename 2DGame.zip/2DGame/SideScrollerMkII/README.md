# SideScrollerMkII

Please have your phone/emulator in landscape mode.

Click left side of screen to jump up, or right side of screen to shoot.
Health items spawn every %300 of the player's score.
Touching a Health item will increase the players HP, but NOT if the player already has 5 HP (full).
Dashers spawn randomly, and increase in speed the higher the player's score.
Boomers spawn every time the player's score is == 400/level.

GAME WILL SLIGHTLY LAG WHEN BOTH ENEMY AND FRIENDLY BULLETS ARE ON SCREEN, BUT THIS IS NORMAL.

Player dies when he falls down a pit, or when his HP = 0,
The game is then reset.
The level end flag will spawn when the player's score == 600*level.

You are able to customize the levels in the updateFloor method inside the GameWorld class.

Thank you and we hope you enjoy our game! :)

